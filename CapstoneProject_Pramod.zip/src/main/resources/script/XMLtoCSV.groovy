import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
 
Message processData(Message message) {
 
    // Read XML payload
    def body = message.getBody(String)
    def xml  = new XmlSlurper().parseText(body)
 
    // Prepare CSV
    def csv = new StringBuilder()
    csv.append("Mandt,ParticipantId,Country,Sfempname,City\n")
 
    // Loop through multiple Empdetails nodes
    xml.Empdetails.each { emp ->
 
        def mandt       = emp.Mandt?.text() ?: ""
        def participant = emp.Participantid?.text() ?: ""
        def country     = emp.Country?.text() ?: ""
        def sfempname   = emp.Sfempname?.text() ?: ""
        def city        = emp.City?.text() ?: ""
 
        csv.append(mandt)
           .append(",")
           .append(participant)
           .append(",")
           .append(country)
           .append(",")
           .append(sfempname)
           .append(",")
           .append(city)
           .append("\n")
    }
 
    // Set CSV as body
    message.setBody(csv.toString())
    message.setHeader("Content-Type", "text/csv")
 
    return message
}